void foo(int i,int j);

void f()
{
    foo(3);
}