void f()
{
    "SkyNet Online" = 666;
}