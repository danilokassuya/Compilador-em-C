void f()
{
    int i;
    if(f()) { i++; }    
    return;
}