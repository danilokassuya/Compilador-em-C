void f()
{
    int i[10],j;

    j = i[1][1];
}