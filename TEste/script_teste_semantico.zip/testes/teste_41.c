void f()
{
    char c;
    int i;
    int* p;
    p = i?&i:&c;
}