void f()
{
    char c;
    int i;
    c = (char)(i?&i:&c);
}