#define v1 2
#define v2 5
#define v3 10
#define v4 1
int i[v3-v1*v2-v4];