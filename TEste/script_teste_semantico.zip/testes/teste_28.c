void f()
{
    int* i = &666;    
    return;
}