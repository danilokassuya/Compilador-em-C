int f(char* a);

void f(char* a)
{
    int i[0];

    return;
}