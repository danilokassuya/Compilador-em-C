void f()
{
    int* p;
    int i;
    i << p;
    return;
}