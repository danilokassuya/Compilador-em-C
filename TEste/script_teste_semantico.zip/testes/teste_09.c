int f(char* a)
{
    int i;

    i = 0;
}