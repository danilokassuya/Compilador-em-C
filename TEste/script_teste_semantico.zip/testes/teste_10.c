void f(char* a)
{
    return 0;
}