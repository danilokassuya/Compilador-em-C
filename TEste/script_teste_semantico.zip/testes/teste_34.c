void f()
{
    int i = &i >= "teste";
    return;
}