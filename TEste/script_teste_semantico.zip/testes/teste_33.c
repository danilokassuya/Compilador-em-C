void f()
{
    int *p,i;
    i = p;
    return;
}