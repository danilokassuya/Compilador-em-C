#define v1 10
#define v2 15
#define constante 1 << (v1-v2)