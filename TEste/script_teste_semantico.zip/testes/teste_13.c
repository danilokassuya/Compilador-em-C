int* f(char* a)
{
    return i;
}