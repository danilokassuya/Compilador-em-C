#define c1 2
#define c2 5
int v[10];
int i = v[c1*c2] + c1;