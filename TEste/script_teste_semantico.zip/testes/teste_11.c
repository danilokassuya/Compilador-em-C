int* f(char* a)
{
    return "SkyNet Online";
}