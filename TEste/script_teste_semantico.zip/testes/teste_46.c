char c = "character";
int l=66,i = (void*) 0;
int z,w=5,x = (void)3;

int main()
{
    return 0;
}