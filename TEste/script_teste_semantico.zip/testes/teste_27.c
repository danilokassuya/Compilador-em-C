void foo(int i,int j);

void f()
{
    char c;
    foo(3,&c);
}