int i;
#define constante i+1