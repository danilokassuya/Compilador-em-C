int* f(char* a)
{
    return;
}