void f()
{
    666++;
}