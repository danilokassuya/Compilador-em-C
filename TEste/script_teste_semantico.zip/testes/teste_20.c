#define v1 2
#define v2 5
#define v3 10
#define constante 1/(v3-v1*v2)