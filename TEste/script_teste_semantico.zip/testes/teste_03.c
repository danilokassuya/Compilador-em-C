void f()
{
    void i;

    return;
}