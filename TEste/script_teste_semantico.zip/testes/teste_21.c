void f()
{
    int i;
    i = f();    
    return;
}