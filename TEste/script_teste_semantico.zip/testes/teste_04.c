void f()
{
    int i[0];

    return;
}