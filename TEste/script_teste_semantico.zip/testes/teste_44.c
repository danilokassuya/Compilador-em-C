#define valor_negativo -15
#define valor_positivo +15
void f()
{
    int* v[valor_positivo];    
    v[valor_negativo] = 
    v[-valor_positivo];
    
    v[valor_negativo]
    =
    2 
    <<
    valor_negativo;
}