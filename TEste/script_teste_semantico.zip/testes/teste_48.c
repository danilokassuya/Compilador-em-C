int main()
{   
    int i = (void) 0;
    
    c = i;
    i = c;
   
    return 0;
}