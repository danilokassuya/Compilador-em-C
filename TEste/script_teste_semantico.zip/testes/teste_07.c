void f(int a);

void f(char a)
{
    int i[0];

    return;
}