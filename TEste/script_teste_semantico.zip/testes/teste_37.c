#define c1 1 >> 32
#define c2 1 << 33