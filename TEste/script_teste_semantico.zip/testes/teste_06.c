void f(int a);

void f(int a, int b)
{
    int i[0];

    return;
}