int main()
{
    if(3?(void)4:(void)5)
    {
        666;
    }
    return 0;
}