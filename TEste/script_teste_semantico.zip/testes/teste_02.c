void f()
{
    int i;
    char i;

    return;
}