int j;
int i[j];