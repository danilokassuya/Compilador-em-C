void f()
{
   int i;
   int i;

   return;
}
