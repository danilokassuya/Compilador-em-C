void f()
{
    666 = "SkyNet Online";
}