void f()
{
    int *i,*j;
    i + j;    
    return;
}