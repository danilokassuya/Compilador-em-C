void f()
{
    int* p;

    +p;
    return;
}