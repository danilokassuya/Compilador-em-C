void f()
{
    int* p;
    int i[10];

    i[p];
    return;
}