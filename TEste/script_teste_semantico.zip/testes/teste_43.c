void f()
{
    char c;
    int i,*p;    
    p = (char)(i?&i:&c);
}